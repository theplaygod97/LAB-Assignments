function [w]=mykaiser(N)
[w]=kaiser(N);
end
clc;clear;close all;
%GIVEN
wp=0.25*pi;
ws=0.35*pi;
Ap=0.1;
As=50;
wc=(ws+wp)/2;
%A=10^(As);
%From A,(beta) value is found which is used as a argument for mykaiser to
%find the required Windowed response
delta_p=(10^(0.1*Ap)-1)/(10^(0.1*As)+1);
delta_s=(10^(0.1*As)-1);
delta=min(delta_p,delta_s);
%ORDER
N=ceil((log10((10^(0.1*Ap)-1)/(10^(0.1*As)+1)))/(2*log10(wp/ws)));
M=N;
%WINDOWING
w=mykaiser(N);
%DESIRED RESPONSE
for n=0:M-1
    hd(n+1)=sin((wc*(n-M/2)))/(pi*(n-M/2));
end
hd(floor(M/2)+1)=pi/wc;
h=hd.*w';
%PLOT
[Mag,W]=freqz(h,1);
H=abs(Mag);
H1=20*log10(H);
figure;
subplot(311)
plot(W,H);title('Magnitude Response');xlabel('Magnitude');ylabel('\omega')
subplot(312)
plot(W,H1);title('Magnitude Response (in dB)');xlabel('Magnitude');ylabel('\omega')
subplot(313)
plot(W,angle(Mag));title('Phase Response');xlabel('Angle');ylabel('\omega')
figure;
subplot(311)
stem(w);title('Kaiser Window');xlabel('Amplitude');ylabel('Time')
subplot(312)
stem(hd);xlabel('Amplitude');ylabel('Time')
subplot(313)
stem(h);xlabel('Amplitude');ylabel('Time')
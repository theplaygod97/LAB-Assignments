/*Author:Satyabrat sahoo
 * Regd.no.:1541016245
 * Branch:ECE
 * Section:A
 * Date:05.10.2015
 * Section:2.3.1
 * Brief description:design an algorithm that calculate the average of n numbers.
 */
import java.util.*;
public class Ques_2_3_1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the total number n = ");
		int n=sc.nextInt();
		float i;
		float s=0,avg;
		for(i=1;i<=n;i++)
		{
			System.out.println("enter the numbers = ");
			float x=sc.nextFloat();
			s=s+x;
		}
		avg=s/n;
		System.out.println("the average of n numbers is =  "+avg);
		// TODO Auto-generated method stub

	}

}

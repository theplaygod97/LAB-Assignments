/*Author:Satyabrat sahoo
 * Regd.no.:1541016245
 * Branch:ECE
 * Section:A
 * Date:05.10.2015
 * Section:2.1.2
 * Brief description:
 */
import java.util.*;
public class Ques_2_2_3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of students ");
		int n=sc.nextInt();
		System.out.println("Enter the pass mark ");
		int pm=sc.nextInt();
		int p=0,m,f;
		for(int i=1;i<=n;i++)
		{
			System.out.println("Enter marks ");
			m=sc.nextInt();
			if(m>=pm)
				p++;
			
		}
		f=n-p;
		System.out.println("no of students passed the exams= "+p);
		System.out.println("no of students failed the exams= "+f);
		// TODO Auto-generated method stub

	}

}

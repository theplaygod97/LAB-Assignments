/*
 *           Global definitions for Reed-Solomon encoder/decoder
 *
 * Modified August 2000, Eritek Inc. (info@eritek.com) to allow all RS parameters to be
 * specified at run time by the calling routine
 *
 * Modified from original code by Phil Karn (karn@ka9q.ampr.org) September 1996
 */

/* Set one of these to enable encoder/decoder debugging and error checking,
 * at the expense of speed */
//#undef DEBUG 1
//#undef DEBUG 2

/* MM, KK, B0 and PRIM are user defined at runtime in this version of the SW */

/* MM is the size of each code symbol in bits. The Reed-Solomon
 * block size will then be NN = 2**M - 1 symbols.
 */

/*
 * KK is the number of data symbols in each block, which must be
 * less than the block size. The code will then be able to correct up
 * to NN-KK erasures or (NN-KK)/2 errors, or combinations thereof with
 * each error counting as two erasures.
 */

/* Set B0 to the first root of the generator polynomial, in alpha form, and
 * set PRIM to the power of alpha used to generate the roots of the
 * generator polynomial. The generator polynomial will then be
 * @**PRIM*B0, @**PRIM*(B0+1), @**PRIM*(B0+2)...@**PRIM*(B0+NN-KK)
 * where "@" represents a lower case alpha.
 */

//#define B0 1		/* First root of generator polynomial, alpha form (Default= 1) */
//#define PRIM 1	/* Power of alpha used to generate roots of generator poly (Default= 1) */


/* If you want to select your own field generator polynomial, you'll have
 * to edit that in rs_vis_dll.c
 */


#if defined(WIN32) /*MSVC 4+ */ | defined(__WIN32__) /* Borland 32 */ | defined(_WINNT_) /*MSVC 32 */
# define EXPORT32 __declspec(dllexport)
#endif

typedef int gf;

/* The structure below allows the specification of all relevant RS parameters from
 * the calling routine.  It also includes dynamic memory pointers to arrays
 * needed by the encoding and decoding functions (you must allocate these arrays
 * prior to calling the RS init function, and free them when exiting the program) */

typedef struct {
	int symbolSize;				// Value of MM (symbol size in bits)
	int inputBytes;				// Value of KK (number of input data symbols)
	int B0;						// B0 (first root of generator polynomial to use), Default= 1
	int PRIM;					// PRIM (power of alpha used to generate the roots), Default= 1
	int rsBlockSize;			// Set to (2**MM)-1
	int A0;						// Set to (2**MM)-1
	int Ldec;						// Internal variable
	gf Pp[11];						// Internal array (see init_rs() routine)
	gf *Index_of;				// Allocate to size 2**MM
	gf *Alpha_to;				// Allocate to size 2**MM
	gf *Gg;						// Allocate to size (2**MM)-KK
	} RS_STRUCT;      


/* For CCSDS standard, use the following:
 *
 *     MM= 8, KK= 223, B0= 112, PRIM= 11
 */


/* Reed-Solomon initialization routine
 * used to generate Galois field, and setup other internal arrays
 *
 * This routine must be called first before calling encode_rs() or eras_dec_rs()
 */

EXPORT32 void init_rs(RS_STRUCT *ptr);


/* Reed-Solomon encoding
 * data[] is the input block, parity symbols are placed in bb[]
 * bb[] may lie past the end of the data, e.g., for (255,223):
 *	encode_rs(&data[0],&data[223]);
 */

EXPORT32 int encode_rs(unsigned int *data, unsigned int *bb, RS_STRUCT *ptr);


/* Reed-Solomon erasures-and-errors decoding
 * The received block goes into data[], and a list of zero-origin
 * erasure positions, if any, goes in eras_pos[] with a count in no_eras.
 *
 * The decoder corrects the symbols in place, if possible and returns
 * the number of corrected symbols. If the codeword is illegal or
 * uncorrectible, the data array is unchanged and -1 is returned
 */

EXPORT32 int eras_dec_rs(unsigned int data[], int eras_pos[], int no_eras, RS_STRUCT *ptr);

/*
 *                    REED-SOLOMON CODING AND DECODING
 *
 * Modified August 2000, Eritek Inc. (info@eritek.com) to allow all RS parameters to be
 * specified at run time by the calling routine
 *
 * Modified from original code by Phil Karn (karn@ka9q.ampr.org) September 1996
 * 
 * This file is derived from Phil Karn's generic RS encoder/decoder, which is
 * in turn based on the program "new_rs_erasures.c" by Robert
 * Morelos-Zaragoza (robert@spectra.eng.hawaii.edu) and Hari Thirumoorthy
 * (harit@spectra.eng.hawaii.edu), Aug 1995
 *
 * Original code Copyright 1999 Phil Karn, KA9Q
 * Generalized modifications Copyright 2000 Eritek Inc.
 *
 * May be used under the terms of the Lesser General Public License (LGPL)
 */

/* This code can be compiled to create a Windows Dynamic Linked Library (DLL) containing
 * the following three exported functions:
 *
 *		init_rs(), encode_rs(), eras_dec_rs()
 */

#include <stdio.h>
#include "rs_vis_dll.h"


/* MM, NN, KK, B0 and PRIM are now user defined at runtime */

/*  Original assignment of polymonials commented out in this version to allow runtime user
	selection of desired RS block size (now performed in init_RS routine). */

/* 
 * Primitive polynomials - see Lin & Costello, Appendix A,
 * and Lee & Messerschmitt, p. 453.

#if(MM == 2)    // Admittedly silly 
int Pp[MM+1] = { 1, 1, 1 };

#elif(MM == 3)
// 1 + x + x^3 
int Pp[MM+1] = { 1, 1, 0, 1 };

#elif(MM == 4)
// 1 + x + x^4
int Pp[MM+1] = { 1, 1, 0, 0, 1 };

#elif(MM == 5)
// 1 + x^2 + x^5
int Pp[MM+1] = { 1, 0, 1, 0, 0, 1 };

#elif(MM == 6)
// 1 + x + x^6
int Pp[MM+1] = { 1, 1, 0, 0, 0, 0, 1 };

#elif(MM == 7)
// 1 + x^3 + x^7
int Pp[MM+1] = { 1, 0, 0, 1, 0, 0, 0, 1 };

#elif(MM == 8)
// 1+x^2+x^3+x^4+x^8
int Pp[MM+1] = { 1, 0, 1, 1, 1, 0, 0, 0, 1 };

#elif(MM == 9)
// 1+x^4+x^9
int Pp[MM+1] = { 1, 0, 0, 0, 1, 0, 0, 0, 0, 1 };

#elif(MM == 10)
// 1+x^3+x^10
int Pp[MM+1] = { 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1 };

#elif(MM == 11)
// 1+x^2+x^11
int Pp[MM+1] = { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

#elif(MM == 12)
// 1+x+x^4+x^6+x^12
int Pp[MM+1] = { 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1 };

#elif(MM == 13)
// 1+x+x^3+x^4+x^13
int Pp[MM+1] = { 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

#elif(MM == 14)
// 1+x+x^6+x^10+x^14
int Pp[MM+1] = { 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 };

#elif(MM == 15)
// 1+x+x^15
int Pp[MM+1] = { 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

#elif(MM == 16)
// 1+x+x^3+x^12+x^16
int Pp[MM+1] = { 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 };

#else
#error "MM must be set in range 2-16"
#endif

*/

/* The following 4 elements now part of RS_STRUCT which can be modified by the user at runtime */

/* index->polynomial form conversion table */
//static gf Alpha_to[NN + 1];

/* Polynomial->index form conversion table */
//static gf Index_of[NN + 1];

/* No legal value in index form represents zero, so
 * we need a special value for this purpose */

//#define A0	(NN)

/* Generator polynomial g(x) in index form */
//static gf Gg[NN - KK + 1];



/* Compute x % NN, where NN is 2**MM - 1,
 * without a slow divide
 */

static gf modnn(int NN, int MM, int x)
{
  while (x >= NN) {
    x -= NN;
    x = (x >> MM) + (x & NN);
  }
  return x;
}

#define	min(a,b)	((a) < (b) ? (a) : (b))

#define	CLEAR(a,n) {\
int ci;\
for(ci=(n)-1;ci >=0;ci--)\
(a)[ci] = 0;\
}

#define	COPY(a,b,n) {\
int ci;\
for(ci=(n)-1;ci >=0;ci--)\
(a)[ci] = (b)[ci];\
}

#define	COPYDOWN(a,b,n) {\
int ci;\
for(ci=(n)-1;ci >=0;ci--)\
(a)[ci] = (b)[ci];\
}


/* Decrement for aux location variable in Chien search */

void gen_ldec(RS_STRUCT *ptr)
{
	int NN;

	NN= ptr->rsBlockSize;
	for(ptr->Ldec= 1; (ptr->Ldec % ptr->PRIM) != 0; ptr->Ldec+= NN)
		;
	ptr->Ldec /= ptr->PRIM;
}

/* generate GF(2**m) from the irreducible polynomial p(X) in Pp[0]..Pp[m]
   lookup tables:  index->polynomial form   alpha_to[] contains j=alpha**i;
                   polynomial form -> index form  index_of[j=alpha**i] = i
   alpha=2 is the primitive element of GF(2**m)
   HARI's COMMENT: (4/13/94) alpha_to[] can be used as follows:
        Let @ represent the primitive element commonly called "alpha" that
   is the root of the primitive polynomial p(x). Then in GF(2^m), for any
   0 <= i <= 2^m-2,
        @^i = a(0) + a(1) @ + a(2) @^2 + ... + a(m-1) @^(m-1)
   where the binary vector (a(0),a(1),a(2),...,a(m-1)) is the representation
   of the integer "alpha_to[i]" with a(0) being the LSB and a(m-1) the MSB. Thus for
   example the polynomial representation of @^5 would be given by the binary
   representation of the integer "alpha_to[5]".
                   Similarily, index_of[] can be used as follows:
        As above, let @ represent the primitive element of GF(2^m) that is
   the root of the primitive polynomial p(x). In order to find the power
   of @ (alpha) that has the polynomial representation
        a(0) + a(1) @ + a(2) @^2 + ... + a(m-1) @^(m-1)
   we consider the integer "i" whose binary representation with a(0) being LSB
   and a(m-1) MSB is (a(0),a(1),...,a(m-1)) and locate the entry
   "index_of[i]". Now, @^index_of[i] is that element whose polynomial 
    representation is (a(0),a(1),a(2),...,a(m-1)).
   NOTE:
        The element alpha_to[2^m-1] = 0 always signifying that the
   representation of "@^infinity" = 0 is (0,0,0,...,0).
        Similarily, the element index_of[0] = A0 always signifying
   that the power of alpha which has the polynomial representation
   (0,0,...,0) is "infinity".
 
*/

// generate_gf function below assumes that memory has been allocated for all dynamic arrays

void generate_gf(RS_STRUCT *ptr)
{
  register int i, mask;
  int MM, NN;

  MM= ptr->symbolSize;
  NN= ptr->rsBlockSize;

  mask = 1;
  ptr->Alpha_to[MM] = 0;
  for (i = 0; i < MM; i++) {
    ptr->Alpha_to[i] = mask;
    ptr->Index_of[ptr->Alpha_to[i]] = i;
    /* If Pp[i] == 1 then, term @^i occurs in poly-repr of @^MM */
    if (ptr->Pp[i] != 0)
      ptr->Alpha_to[MM] ^= mask;	/* Bit-wise EXOR operation */
    mask <<= 1;	/* single left-shift */
  }
  ptr->Index_of[ptr->Alpha_to[MM]] = MM;
  /*
   * Have obtained poly-repr of @^MM. Poly-repr of @^(i+1) is given by
   * poly-repr of @^i shifted left one-bit and accounting for any @^MM
   * term that may occur when poly-repr of @^i is shifted.
   */
  mask >>= 1;
  for (i = MM + 1; i < NN; i++) {
    if (ptr->Alpha_to[i - 1] >= mask)
      ptr->Alpha_to[i] = ptr->Alpha_to[MM] ^ ((ptr->Alpha_to[i - 1] ^ mask) << 1);
    else
      ptr->Alpha_to[i] = ptr->Alpha_to[i - 1] << 1;
    ptr->Index_of[ptr->Alpha_to[i]] = i;
  }
  ptr->Index_of[0] = ptr->A0;
  ptr->Alpha_to[NN] = 0;
}

/*
 * Obtain the generator polynomial of the TT-error correcting, length
 * NN=(2**MM -1) Reed Solomon code from the product of (X+@**(B0+i)), i = 0,
 * ... ,(2*TT-1)
 *
 * Examples:
 *
 * If B0 = 1, TT = 1. deg(g(x)) = 2*TT = 2.
 * g(x) = (x+@) (x+@**2)
 *
 * If B0 = 0, TT = 2. deg(g(x)) = 2*TT = 4.
 * g(x) = (x+1) (x+@) (x+@**2) (x+@**3)
 */

// gen_poly function below assumes that memory has been allocated for all dynamic arrays

void gen_poly(RS_STRUCT *ptr)
{
  register int i, j;
  int NN, MM, KK;
  gf exponent;				// integer type

  NN= ptr->rsBlockSize;
  MM= ptr->symbolSize;
  KK= ptr->inputBytes;

  ptr->Gg[0] = 1;
  for (i = 0; i < NN - KK; i++) {
    ptr->Gg[i+1] = 1;
    /*
     * Below multiply (Gg[0]+Gg[1]*x + ... +Gg[i]x^i) by
     * (@**(B0+i)*PRIM + x)
     */
    for (j = i; j > 0; j--)
		if (ptr->Gg[j] != 0) {
			exponent=ptr->Alpha_to[modnn(NN,MM,ptr->Index_of[ptr->Gg[j]]+(ptr->B0 + i)*ptr->PRIM)];
			ptr->Gg[j] = ptr->Gg[j - 1] ^ exponent;
		}
		else
			ptr->Gg[j] = ptr->Gg[j - 1];
    /* Gg[0] can never be zero */
    ptr->Gg[0] = ptr->Alpha_to[modnn(NN,MM,ptr->Index_of[ptr->Gg[0]]+(ptr->B0 + i) *ptr->PRIM)];
  }
  /* convert Gg[] to index form for quicker encoding */
  for (i = 0; i <= NN - KK; i++)
    ptr->Gg[i] = ptr->Index_of[ptr->Gg[i]];
}


/*
 * take the string of symbols in data[i], i=0..(k-1) and encode
 * systematically to produce NN-KK parity symbols in bb[0]..bb[NN-KK-1] data[]
 * is input and bb[] is output in polynomial form. Encoding is done by using
 * a feedback shift register with appropriate connections specified by the
 * elements of Gg[], which was generated above. Codeword is   c(X) =
 * data(X)*X**(NN-KK)+ b(X)
 */

// encode_rs assumes that memory has been allocated for all dynamic arrays and init_rs called

EXPORT32 int encode_rs(unsigned int *data, unsigned int *bb, RS_STRUCT *ptr)
{
  register int i, j;
  gf feedback;
  int NN, MM, KK;

  NN= ptr->rsBlockSize;
  MM= ptr->symbolSize;
  KK= ptr->inputBytes;

  CLEAR(bb,NN-KK);

  for(i = KK - 1; i >= 0; i--) {
    feedback = ptr->Index_of[data[i] ^ bb[NN - KK - 1]];
    if (feedback != ptr->A0) {	/* feedback term is non-zero */
      for (j = NN - KK - 1; j > 0; j--)
	if (ptr->Gg[j] != ptr->A0)
	  bb[j] = bb[j - 1] ^ ptr->Alpha_to[modnn(NN,MM,ptr->Gg[j] + feedback)];
	else
	  bb[j] = bb[j - 1];
      bb[0] = ptr->Alpha_to[modnn(NN,MM,ptr->Gg[0] + feedback)];
    } else {	/* feedback term is zero. encoder becomes a
		 * single-byte shifter */
      for (j = NN - KK - 1; j > 0; j--)
		bb[j] = bb[j - 1];
      bb[0] = 0;
    }
  }
  return 0;
}

/*
 * Performs ERRORS+ERASURES decoding of RS codes. If decoding is successful,
 * writes the codeword into data[] itself. Otherwise data[] is unaltered.
 *
 * Return number of symbols corrected, or -1 if codeword is illegal
 * or uncorrectable. If eras_pos is non-null, the detected error locations
 * are written back. NOTE! This array must be at least NN-KK elements long.
 * 
 * First "no_eras" erasures are declared by the calling program. Then, the
 * maximum # of errors correctable is t_after_eras = floor((NN-KK-no_eras)/2).
 * If the number of channel errors is not greater than "t_after_eras" the
 * transmitted codeword will be recovered. Details of algorithm can be found
 * in R. Blahut's "Theory ... of Error-Correcting Codes".

 * Warning: the eras_pos[] array must not contain duplicate entries; decoder failure
 * will result. The decoder *could* check for this condition, but it would involve
 * extra time on every decoding operation.
 */

// decode_rs assumes that memory has been allocated for all dynamic arrays and init_rs called

EXPORT32 int eras_dec_rs(unsigned int *data, int *eras_pos, int no_eras, RS_STRUCT *ptr)
{
	int deg_lambda, el, deg_omega;
	int i, j, r,k;
	gf u,q,tmp,num1,num2,den,discr_r;
	int NN, MM, KK;

//	gf lambda[NN-KK + 1], s[NN-KK + 1];	/* Err+Eras Locator poly and syndrome poly */
//	gf b[NN-KK + 1], t[NN-KK + 1], omega[NN-KK + 1];
//	gf root[NN-KK], reg[NN-KK + 1], loc[NN-KK];

// Above array declarations replaced by fixed allocation below, which is set to support a
// maximum size of M= 10 (NN= 1023) since MM, NN and KK are user defined at runtime in this
// version of the SW.  A bit wasteful on memory, but allows runtime setting of RS parameters.

	gf lambda[1024], s[1024];
	gf b[1024], t[1024], omega[1024];
	gf root[1024], reg[1024], loc[1024];

	int syn_error, count;

	NN= ptr->rsBlockSize;
	MM= ptr->symbolSize;
	KK= ptr->inputBytes;

	  /* form the syndromes; i.e., evaluate data(x) at roots of g(x)
	   * namely @**(B0+i)*PRIM, i = 0, ... ,(NN-KK-1)
	   */
	for(i=1;i<=NN-KK;i++){
		s[i] = data[0];
	}
	for(j=1;j<NN;j++){
		if(data[j] == 0)
			continue;
		tmp = ptr->Index_of[data[j]];
    
		/*	s[i] ^= Alpha_to[modnn(tmp + (B0+i-1)*j)]; */
		for(i=1;i<=NN-KK;i++)
			s[i] ^= ptr->Alpha_to[modnn(NN,MM, tmp + (ptr->B0+i-1) * ptr->PRIM*j)];
	}
	/* Convert syndromes to index form, checking for nonzero condition */
	syn_error = 0;
	for(i=1;i<=NN-KK;i++){
		syn_error |= s[i];
		s[i] = ptr->Index_of[s[i]];
	}
  
	if (!syn_error) {
		/* if syndrome is zero, data[] is a codeword and there are no
		 * errors to correct. So return data[] unmodified
		 */
		count = 0;
		goto finish;
	}
	CLEAR(&lambda[1],NN-KK);
	lambda[0] = 1;

	if (no_eras > 0) {
		/* Init lambda to be the erasure locator polynomial */
		lambda[1] = ptr->Alpha_to[modnn(NN,MM, ptr->PRIM * eras_pos[0])];
		for (i = 1; i < no_eras; i++) {
			u = modnn(NN,MM, ptr->PRIM * eras_pos[i]);
			for (j = i+1; j > 0; j--) {
				tmp = ptr->Index_of[lambda[j - 1]];
			if(tmp != ptr->A0)
				lambda[j] ^= ptr->Alpha_to[modnn(NN,MM, u + tmp)];
		}
    }
#if DEBUG >= 1
    /* Test code that verifies the erasure locator polynomial just constructed
       Needed only for decoder debugging. */
    
    /* find roots of the erasure location polynomial */
    for(i=1;i<=no_eras;i++)
		reg[i] = ptr->Index_of[lambda[i]];
    count = 0;
    for (i = 1,k=NN - ptr->Ldec; i <= NN; i++,k = modnn(NN,MM, NN + k - ptr->Ldec)) {
		q = 1;
		for (j = 1; j <= no_eras; j++)
			if (reg[j] != A0) {
				reg[j] = modnn(NN,MM, reg[j] + j);
				q ^= ptr->Alpha_to[reg[j]];
			}
		if (q != 0)
			continue;
		/* store root and error location number indices */
		root[count] = i;
		loc[count] = k;
		count++;
    }
    if (count != no_eras) {
		printf("\n lambda(x) is WRONG\n");
		count = -1;
		goto finish;
    }
#if DEBUG >= 2
    printf("\n Erasure positions as determined by roots of Eras Loc Poly:\n");
    for (i = 0; i < count; i++)
		printf("%d ", loc[i]);
    printf("\n");
#endif
#endif
	}
	for(i=0;i<NN-KK+1;i++)
		b[i] = ptr->Index_of[lambda[i]];
  
	  /*
	   * Begin Berlekamp-Massey algorithm to determine error+erasure
	   * locator polynomial
	   */
	r = no_eras;
	el = no_eras;
	while (++r <= NN-KK) {	/* r is the step number */
    /* Compute discrepancy at the r-th step in poly-form */
		discr_r = 0;
		for (i = 0; i < r; i++){
			if ((lambda[i] != 0) && (s[r - i] != ptr->A0)) {
				discr_r ^= ptr->Alpha_to[modnn(NN,MM, ptr->Index_of[lambda[i]] + s[r - i])];
			}
		}
		discr_r = ptr->Index_of[discr_r];	/* Index form */
		if (discr_r == ptr->A0) {
			/* 2 lines below: B(x) <-- x*B(x) */
			COPYDOWN(&b[1],b,NN-KK);
			b[0] = ptr->A0;
		} else {
		/* 7 lines below: T(x) <-- lambda(x) - discr_r*x*b(x) */
			t[0] = lambda[0];
			for (i = 0 ; i < NN-KK; i++) {
				if(b[i] != ptr->A0)
					t[i+1] = lambda[i+1] ^ ptr->Alpha_to[modnn(NN,MM, discr_r + b[i])];
				else
					t[i+1] = lambda[i+1];
			}
			if (2 * el <= r + no_eras - 1) {
				el = r + no_eras - el;
				/*
				 * 2 lines below: B(x) <-- inv(discr_r) *
				 * lambda(x)
				 */
				for (i = 0; i <= NN-KK; i++)
					b[i] = (lambda[i]==0) ? ptr->A0 : modnn(NN,MM,ptr->Index_of[lambda[i]] - 
						discr_r + NN);
			} else {
				/* 2 lines below: B(x) <-- x*B(x) */
				COPYDOWN(&b[1],b,NN-KK);
				b[0] = ptr->A0;
			}
			COPY(lambda,t,NN-KK+1);
		}
	}

	/* Convert lambda to index form and compute deg(lambda(x)) */
	deg_lambda = 0;
	for(i=0;i<NN-KK+1;i++){
		lambda[i] = ptr->Index_of[lambda[i]];
		if(lambda[i] != ptr->A0)
			deg_lambda = i;
	}
	  /*
	   * Find roots of the error+erasure locator polynomial by Chien
	   * Search
	   */
	COPY(&reg[1],&lambda[1],NN-KK);
	count = 0;		/* Number of roots of lambda(x) */
	for (i = 1,k=NN - ptr->Ldec; i <= NN; i++,k = modnn(NN,MM, NN + k - ptr->Ldec)) {
		q = 1;
		for (j = deg_lambda; j > 0; j--){
			if (reg[j] != ptr->A0) {
				reg[j] = modnn(NN,MM, reg[j] + j);
				q ^= ptr->Alpha_to[reg[j]];
			}
		}
		if (q != 0)
			continue;
		/* store root (index-form) and error location number */
		root[count] = i;
		loc[count] = k;
		/* If we've already found max possible roots,
		 * abort the search to save time
		 */
		if(++count == deg_lambda)
			break;
	}
	if (deg_lambda != count) {
		/*
		 * deg(lambda) unequal to number of roots => uncorrectable
		 * error detected
		 */
		count = -1;
		goto finish;
	}
	  /*
	   * Compute err+eras evaluator poly omega(x) = s(x)*lambda(x) (modulo
	   * x**(NN-KK)). in index form. Also find deg(omega).
	   */
	deg_omega = 0;
	for (i = 0; i < NN-KK;i++){
		tmp = 0;
		j = (deg_lambda < i) ? deg_lambda : i;
		for(;j >= 0; j--){
			if ((s[i + 1 - j] != ptr->A0) && (lambda[j] != ptr->A0))
			tmp ^= ptr->Alpha_to[modnn(NN,MM, s[i + 1 - j] + lambda[j])];
		}
		if(tmp != 0)
		deg_omega = i;
		omega[i] = ptr->Index_of[tmp];
	}
	omega[NN-KK] = ptr->A0;
  
	  /*
	   * Compute error values in poly-form. num1 = omega(inv(X(l))), num2 =
	   * inv(X(l))**(B0-1) and den = lambda_pr(inv(X(l))) all in poly-form
	   */
	for (j = count-1; j >=0; j--) {
		num1 = 0;
		for (i = deg_omega; i >= 0; i--) {
			if (omega[i] != ptr->A0)
				num1  ^= ptr->Alpha_to[modnn(NN,MM, omega[i] + i * root[j])];
		}
		num2 = ptr->Alpha_to[modnn(NN,MM, root[j] * (ptr->B0 - 1) + NN)];
		den = 0;
    
		/* lambda[i+1] for i even is the formal derivative lambda_pr of lambda[i] */
		for (i = min(deg_lambda,NN-KK-1) & ~1; i >= 0; i -=2) {
			if(lambda[i+1] != ptr->A0)
				den ^= ptr->Alpha_to[modnn(NN,MM, lambda[i+1] + i * root[j])];
		}
		if (den == 0) {
#if DEBUG >= 1
			printf("\n ERROR: denominator = 0\n");
#endif
			/* Convert to dual- basis */
			count = -1;
			goto finish;
		}
		/* Apply error to data */
		if (num1 != 0) {
			data[loc[j]] ^= ptr->Alpha_to[modnn(NN,MM,ptr->Index_of[num1] +
				ptr->Index_of[num2] + NN - ptr->Index_of[den])];
		}
	}
	finish:
    if(eras_pos != NULL){
		for(i=0;i<count;i++){
		if(eras_pos!= NULL)
			eras_pos[i] = loc[i];
		}
    }
    return count;
}

/* Encoder/decoder initialization - call this first! */

EXPORT32 void init_rs(RS_STRUCT *ptr)
{	
	int i;
	
/* Primitive polynomials - see Lin & Costello, Appendix A,
 * and  Lee & Messerschmitt, p. 453.
 */
	for(i=0; i <= 10; i++)				// initiliaze all entries to zero
		ptr->Pp[i]= 0;

	switch (ptr->symbolSize) {
	case 3:
		ptr->Pp[0]= 1;
		ptr->Pp[1]= 1;
		ptr->Pp[3]= 1;
		break;
	case 4:
		ptr->Pp[0]= 1;
		ptr->Pp[1]= 1;
		ptr->Pp[4]= 1;
		break;
	case 5:
		ptr->Pp[0]= 1;
		ptr->Pp[2]= 1;
		ptr->Pp[5]= 1;
		break;
	case 6:
		ptr->Pp[0]= 1;
		ptr->Pp[1]= 1;
		ptr->Pp[6]= 1;
		break;
	case 7:
		ptr->Pp[0]= 1;
		ptr->Pp[3]= 1;
		ptr->Pp[7]= 1;
		break;
	case 8:
		ptr->Pp[0]= 1;
		ptr->Pp[2]= 1;
		ptr->Pp[3]= 1;
		ptr->Pp[4]= 1;
		ptr->Pp[8]= 1;
		break;
	case 9:
		ptr->Pp[0]= 1;
		ptr->Pp[4]= 1;
		ptr->Pp[9]= 1;
		break;
	case 10:
		ptr->Pp[0]= 1;
		ptr->Pp[3]= 1;
		ptr->Pp[10]= 1;
		break;
	}
	generate_gf(ptr);
	gen_poly(ptr);

	if(ptr->PRIM != 1)
		gen_ldec(ptr);
	else
		ptr->Ldec= 1;
}

/*************************** End of File ***************************/

#include<stdio.h>
int power(int n,int m);
int main()
{
int base,exp;
printf("Enter the base number");
scanf("%d",&base);
printf("Enter the power");
scanf("%d",exp);
printf("%d^%d=%d",base,exp,power(base,exp));
return 0 ;
}
int power(int base,int exp)
{
if(exp!=1)
return(base*power(base,exp-1));
}

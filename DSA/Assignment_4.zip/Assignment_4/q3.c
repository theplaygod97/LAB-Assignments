#include <stdio.h>
int check(int n);
int main(){
    int num,num_check=0;
    printf("Enter positive  no  to check:\n");
    scanf("%d",&num);
    num_check=check(num); 
    if(num_check==1)
       printf("%d is not prime",num);
    else
       printf("%d is prime",num);
    return 0;
}
int check(int n){   
 
    int i;
    for(i=2;i<=n/2;++i){
    if(n%i==0)
        return 1;
}
   return 0;
}


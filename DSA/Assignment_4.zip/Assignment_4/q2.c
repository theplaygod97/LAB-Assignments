#include<stdio.h>
#include<math.h>

int prime(int n)
{
int i,flag=1;
for(int i=2;i<=abs(sqrt(n));i++)
{
if(n%i==0)
{
flag=o;
return 0;
}
}
return 1;
}

int main
{
int n,x;
printf("Input x");
scanf("%d"&n);
x=prime(n);
if(x==1)
printf("Prime");
else
printf("Not prime");
return 0;
}

#include<stdio.h>
int power(int,int);
int factorial(int,int);
float series(int,int);
int main()
{
int n,x;
float series(int x,int n)
{
int i;
float ex=0
for(i=0;i<=n;i+1)
{
ex=ex+(float)power(x,i)/factorial(i);
}
return ex;
}
}
int power(int x,int y)
{
int i,p=1
for(i=1;i<=y;i++)
p=p*x;
return p;
}
int factorial(int n)
{
int fact=1,i;
for(i=1;i<=n;i++)
fact=fact*i;
return fact;
}

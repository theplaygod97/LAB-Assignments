#include<stdio.h>
int main()
{
 char ch[10];
 int i,count=0;
 printf("Enter the string\n");
 gets(ch);
 for(i=0;ch[i]!='\0';i++)
 {
  if(ch[i]=='a' || ch[i]=='e' || ch[i]=='i' || ch[i]=='o'
   || ch[i]=='u')
  {
   count++;
  }
 }
 printf("Vowels = %d",count);
 return 0;
}

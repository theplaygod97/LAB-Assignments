#include<stdio.h>
int main()
{
      int a[10],odd=0,even=0,neg=0,pos=0,i;
      printf("\nEnter 10 Elements : ");
      for(i=0;i<10;i++)
            scanf("%d",&a[i]);
      for(i=0;i<10;i++)
      {
            if(a[i]>=0)
                  pos++;
            else
                  neg++;
            if(a[i]%2==0)
                  even++;
            else
                  odd++;
      }
      printf("\nTotal no of Positive Numbers : %d",pos);
      printf("\nTotal no of Negative Numbers : %d",neg);
      printf("\nTotal no of Even Number : %d",even);
      printf("\nTotal no of Odd Numbers : %d",odd);
      return 0;     
}

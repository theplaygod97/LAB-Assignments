#include<stdio.h>
int main()
{
int a[100],i,max,smax,n,s;
printf("Enter the elements");
for(i=0;i<100;i++)
scanf("%d",&a[i]);
smax=0;
max=a[0];
for(i=0;i<n;i++)
    {
       if(a[i]>max)
{
smax=max;
max=a[i];
}
else if (a[i]>smax)
{
smax=a[i]


s=0;
s=s+i;
printf("\nLargest element = %.2d",max);
printf("\nsecond largest = %.2d",smax);
printf("\nsum = %.2d",s);
}
    return 0;
}

/*
 Name - satyabrat sahoo
Regd no - 1541016245
Branch - ECE A
 
 Date:7th feburary 2016
 Chapter and Problem No.: Chapter 1 Problem 13
 Brief Description: Write a C program to determine on what day the price drops to less than half of the original price.
*/

#include<stdio.h>
int main()
{
	float p,d,n=0,a;
	printf("Enter the price of product\n");
	scanf("%f",&p);
	a=p;
	printf("Enter the discount\n");
	scanf("%f",&d);
	int c=0;
	while(p>=(a/2))
	{
		n=(float)((d/100)*p);
		p=p-n;
		c++;
	}
	printf("After %d day the price drops to the half of orignal\n",c);

return 0;
}

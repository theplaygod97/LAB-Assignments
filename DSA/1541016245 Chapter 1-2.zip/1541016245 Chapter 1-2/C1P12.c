/*
 Name - satyabrat sahoo
Regd no - 1541016245
Branch - ECE A
 Date:7th feburary 2016
 Chapter and Problem No.: Chapter 1 Problem 12
 Brief Description: Write a C program to print the number of day and the amount of water left at the end of that day.
*/

#include<stdio.h>
int main()
{
	int w,i;
	float p,left,a;
	printf("Enter the Liters of water\n");
	scanf("%d",&w);
	for(i=1;i<30;i++)
	{
		printf("Enter the pecentage of water of day %d\n",i);
		scanf("%f",&p);
		a=(float)((p/100)*w);
		left=w-a;
		if(left<100)
		{
			printf("Less than 100 liters\n");
			break;
		}
		else
		{
			printf("Left Water=%f\n",left);
			w=left;
		}
	}
return 0;
}	

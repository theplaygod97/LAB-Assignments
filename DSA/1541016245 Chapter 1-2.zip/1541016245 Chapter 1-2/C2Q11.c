/*
 
 Name - satyabrat sahoo
Regd no - 1541016245
Branch - ECE A
 Date:7th feburary 2016
 Chapter and Problem No: Chapter 2 Problem 11
 Brief Description: Write a C program to determine which bulbs are off at the end of the exercise.
*/

#include<stdio.h>
//0 is OFF & 1 is ON
int main()
{
		int a[500],i,j;
		 for(i=0;i<500;i++){
			 a[i]=0;
		}
		for(i=2;i<500;i++)
 		{
   		for(j=i;j<500;j=j+i)
   	 	{
		if(a[i]==0)
      			a[i]=1;
     		else if(a[i]==1)
      			a[i]=0;
  	  	}		
 		
	}
 
 		for(i=0;i<500;i++)
 		printf("%d",a[i]);
 return 0;
}	

/*
 
 Name - satyabrat sahoo
Regd no - 1541016245
Branch - ECE A
 Date:7th feburary 2016
 Chapter and Problem No.: Chapter 1 Problem 14
 Brief Description: Write a C program to determine which items earned the most and least revenue.
*/

#include<stdio.h>
int main()
{
	int p,n,q,c=1,i=1,tp,m,mi,r=1,t;
	while(c!=0)
	{
		printf("Enter the price and quantity\n");
		scanf("%d%d",&p,&q);
		tp=p*q;
		if(tp>m)
		{
			m=tp;
			n=i;
		}
		i++;
	if(tp<mi)
	{
	mi=tp;
	t=r;
	}
	r++;
		printf("Enter '1' to continue or '0' to terminate\n");
		scanf("%d",&c);
	}
	printf("The max revenue  was %d of item no %d\n",m,n);
	printf("The minimum revenue was %d of item no %d\n",mi,t);

return 0;
}	
